#include <iostream>
#include <string>
using namespace std;

void printMenu(int menu) {
	char daftar;
	int n;
	int jml;
	int byr;
	string x;
	string y;
	char beli_jual;
	
	string nama[5] = {"BBCA", "ASII", "ANTM", "GOTO", "BUMI"};
	int harga[5] = {8250, 6350, 1825, 200, 175};
	
	system ("cls"); 
	
	switch (menu){
		case 1:
		cout << "Masukkan Username\t: ";
		cin >> x;
		cout << "\nMasukkan Password\t: ";
		cin >> y;
		system ("cls");
		m:
			system ("cls");
			cout<<"Selamat Datang "<<x<<" di STOCKTRADE\n";
			cout<<"=================================================\n"<<endl;
			for( int i = 0; i < 5; i++) {
				cout<<i+1<<"."<<nama[i]<<"\t\tRp. "<<harga[i]<<endl;
			}cout<<"\n(Harga per lembar saham)"<<endl;
			cout<<"=================================================\n"<<endl;
		bj:	
		cout<<"Beli (B)\nJual (j)\n";
		cin>>beli_jual;
		if (beli_jual == 'J' || beli_jual == 'j'){
				goto jual;
			}else if(beli_jual == 'B' || beli_jual == 'b'){
				goto k;
			}else{
				goto m;
			}
		jual:
		system ("cls");
		cout<<"Selamat Datang "<<x<<" di STOCKTRADE\n";
			cout<<"=================================================\n"<<endl;
			for( int i = 0; i < 5; i++) {
				cout<<i+1<<"."<<nama[i]<<"\t\tRp. "<<harga[i]<<endl;
			}cout<<"\n(Harga per lembar saham)"<<endl;
			cout<<"=================================================\n"<<endl;
		cout << "Silahkan masukkan saham yang ingin anda jual (masukkan nomor saham)\t: ";
		cin >> n;	
		if(n < 1 || n > 5) {
			cout << "Saham tidak tersedia!\n";
			goto balik;
			
		}else{
		cout <<"\n"<<n<<"."<<nama[n-1]<<endl;
	    cout << "Masukkan jumlah yang anda inginkan \t\t: ";
	    cin >> jml;
	    cout << "Total harga \t\t\t\t\t: Rp. "<< 100*jml*harga[n-1] << endl;
		}
	
		y:
		cout << "Apakah anda yakin ingin menjualnya? (Y/T)\t: ";
	    cin  >> daftar;
	    if(daftar=='Y'||daftar=='y'){
	    	cout<<"\nPenjualan berhasil!" << endl;
	    	cout<<"Anda mendapatkan saldo sebesar\t\t\t: Rp. "<< 100*jml*harga[n-1]<<endl;
	    	goto j;
		}else if(daftar=='T'||daftar=='t'){
			cout<<"\nPenjualan dibatalkan!"<<endl;
			cout<<"Anda telah membatalkan penjualan"<<endl;
			goto balik;
		}else{
			goto y;
		}
		
		
		k:
			system ("cls");
		cout<<"Selamat Datang "<<x<<" di STOCKTRADE\n";
			cout<<"=================================================\n"<<endl;
			for( int i = 0; i < 5; i++) {
				cout<<i+1<<"."<<nama[i]<<"\t\tRp. "<<harga[i]<<endl;
			}cout<<"\n(Harga per lembar saham)"<<endl;
			cout<<"=================================================\n"<<endl;
		cout << "Silahkan masukkan saham yang ingin anda beli (masukkan nomor saham)\t: ";
		cin >> n;
		if(n < 1 || n > 5) {
			cout << "Saham tidak tersedia!\n";
			goto balik;
			
			}else {
			cout <<"\n"<<n<<"."<<nama[n-1]<<endl;
	        cout << "Masukkan jumlah yang anda inginkan \t\t: ";
	        cin >> jml;
	        cout << "Total harga \t\t\t\t\t: Rp. "<< 100*jml*harga[n-1] << endl;
	        cout << "Bayar \t\t\t\t\t\t: Rp. ";
	        cin >> byr;
		        
	        while(byr < (100 * jml * harga[n-1])) {
	        	cout<<"\nPembelian gagal!";
	        	cout << "\nMaaf saldo anda tidak cukup \t\t\t"<< endl;
	        	goto balik;
	        	break;
	        
			}if(jml * harga[n-1] <= byr) {	
				cout << "\nPembelian berhasil!"<<endl;
	        	cout << "Saldo anda tersisa\t\t\t\t: Rp. "<< byr - (100*jml*harga[n-1]) << endl;
			}
		}
		j:
		cout << "Kembali (Y)\nKeluar (T)  \n";
		cin >> daftar;
			
		if (daftar == 'T' || daftar == 't'){
			system("cls");
	    cout << "         ================================================================================================= "<<endl;
	    cout << "        |                                                                                                 |"<<endl;
		cout << "        |                            Terimakasih sudah mengunjungi STOCKTRADE                             |"<<endl;
		cout << "        |                                                                                                 |"<<endl;
		cout << "         ================================================================================================= "<<endl;
			exit(0);
		} else if (daftar == 'Y' || daftar == 'y'){
			while(beli_jual == 'B' || beli_jual == 'b'){
			harga[n-1]=25+harga[n-1];
			goto m;
		}   if (beli_jual == 'J' || beli_jual == 'j'){
			harga[n-1]=harga[n-1]-25;
			goto m;
		}
		} else {
			system("cls");
			goto j;
			
		}
		balik:
		cout << "Kembali (Y)\nKeluar (T)  \n";
		cin >> daftar;
			
		if (daftar == 'T' || daftar == 't'){
			system("cls");
	    cout << "         ================================================================================================= "<<endl;
	    cout << "        |                                                                                                 |"<<endl;
		cout << "        |                            Terimakasih sudah mengunjungi STOCKTRADE                             |"<<endl;
		cout << "        |                                                                                                 |"<<endl;
		cout << "         ================================================================================================= "<<endl;
			exit(0);
		} else if (daftar == 'Y' || daftar == 'y'){
			goto m;
		} else {
			system("cls");
			goto balik;
	
	}

}
}

int main(){	
	int menu;
	char e;

	menu:
		system("cls");
	    cout << "         ================================================================================================= "<<endl;
	    cout << "        |                                                                                                 |"<<endl;
		cout << "        |                                   Selamat datang di STOCKTRADE                                  |"<<endl;
		cout << "        |                                                                                                 |"<<endl;
		cout << "         ================================================================================================= "<<endl;
		cout << "\nLOGIN (Y)" << endl;
		cin  >> e;
		
		if(e=='Y'||e=='y'){
		printMenu(1);
	}else{
		goto menu;
	}
}
